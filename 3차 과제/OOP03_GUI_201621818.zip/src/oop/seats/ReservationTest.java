package oop.seats;

public class ReservationTest {
	
	public static void main(String[] args){
		Manager helper = new Manager();
		while(true) {
			int userChoice = Manager.printMenu();
			System.out.println(userChoice);
			switch(userChoice) {
				case 1:
					helper.reserve(true);
					break;
				case 2:
					helper.reserve(false);
					break;
			}
			userChoice = 0;
		}
		
	}
}