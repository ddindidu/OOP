package oop.seats;

import javax.swing.*;

public class ButtonFrame {
	private int seati=0, seatj=0;
	private JButton btn;
	
	public ButtonFrame() {
		btn = new JButton();
	}
	
	public ButtonFrame(String name, int i, int j) {
		seati=i; seatj=j;
		btn = new JButton(name);
	}
	
	public JButton getButton() {
		return btn;
	}
	
	public int getRow() {
		return seati;
	}
	
	public int getCol() {
		return seatj;
	}
}
