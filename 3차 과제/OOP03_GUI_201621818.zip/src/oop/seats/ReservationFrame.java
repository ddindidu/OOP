package oop.seats;

import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.*;

public class ReservationFrame extends MainFrame{
	private final int START_TIME = 9;
	private final int END_TIME = 18;
	private JFrame rsrvFrame;
	private JPanel rsrvPanel, seatPanel, timePanel, timeLabelPanel; // time �߰�
	private JButton enterBtn;
	private ArrayList<JButton> timeBtn;
	private JTextField yearTF, monthTF, dayTF;
	private JLabel yearL, monthL, dayL, seatL;
	String syear, smonth, sday, sstartTime, sendTime;
	int year, month, day, startTime, endTime;
	int seati, seatj;
	// ������ �Ϸ��ϸ� false
	boolean isEnable;
	boolean reserveFlag;
	Seat rsrvSeat;
	
	
	public ReservationFrame(boolean flag) {
		isEnable = true; reserveFlag = flag;
		rsrvFrame = new JFrame();
		setFrame(rsrvFrame, "�¼� " + (reserveFlag ? "�����ϱ�" : "����/����ϱ�"));
		
		rsrvPanel = new JPanel();
		rsrvFrame.add(rsrvPanel, BorderLayout.NORTH);
		rsrvPanel.setLayout(new GridLayout(1,3));
		
		LocalDate date = LocalDate.now();
		yearTF = new JTextField(Integer.toString(date.getYear()),4);
		monthTF = new JTextField(Integer.toString(date.getMonthValue()),4);
		dayTF = new JTextField(Integer.toString(date.getDayOfMonth()),4);
		rsrvPanel.add(addLabelAndText(yearTF, "��"));
		rsrvPanel.add(addLabelAndText(monthTF, "��"));
		rsrvPanel.add(addLabelAndText(dayTF, "��"));
		// �ڸ� ǥ
		seatPanel = new JPanel();
		seatPanel.setLayout(new GridLayout(5,5));
		rsrvFrame.add(seatPanel, BorderLayout.CENTER);
		makeSeatBtn();
		
		// Ÿ�����̺� + ���� ��ư
		timePanel = new JPanel();
		timePanel.setLayout(new GridLayout(6,2));
		rsrvFrame.add(timePanel, BorderLayout.SOUTH);
		// ���� Ȯ��
		yearL = new JLabel(); monthL = new JLabel(); dayL = new JLabel(); seatL = new JLabel();
		yearL.setHorizontalAlignment(JLabel.CENTER); monthL.setHorizontalAlignment(JLabel.CENTER);
		dayL.setHorizontalAlignment(JLabel.CENTER);	seatL.setHorizontalAlignment(JLabel.CENTER);
		// ����
		timeLabelPanel = new JPanel();
		timeLabelPanel.setLayout(new GridLayout(1,3));
		timeLabelPanel.add(yearL);
		timeLabelPanel.add(monthL);
		timeLabelPanel.add(dayL);
		timePanel.add(timeLabelPanel);
		// ����
		timePanel.add(seatL);
		// �ð��� ��ư ArrayList�� ����
		timeBtn = new ArrayList<>();
		makeTimeBtn();
		
		// �Ϸ��ư
		enterBtn = new JButton((reserveFlag ? "����" : "���") + " �Ϸ� ^3^");
		enterBtn.addActionListener(event->{
			isEnable = false;
			rsrvFrame.setVisible(false);
		});
		timePanel.add(enterBtn);
		
		rsrvFrame.setVisible(true);
	}
	// ó���� ��Ȱ��ȭ�Ұ��� flag ����
	public JPanel addLabelAndText(JTextField tf, String l) {
		JPanel panel = new JPanel();
		JLabel label = new JLabel(l);
		panel.add(tf, BorderLayout.WEST);
		panel.add(label, BorderLayout.EAST);
		return panel;
	}
	
	public void makeSeatBtn() {
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=5; j++) {
				String seatNum = "<"+i+", "+j+">";
				ButtonFrame btnInfo = new ButtonFrame(seatNum, i, j);
				JButton btn = btnInfo.getButton();
				// �¼��� ������ ������ ������ rsrv�� ����� 
				btn.addActionListener(event->{
					if(yearTF.getText().equals("") || monthTF.getText().equals("") || dayTF.getText().equals("")
							|| !Time.checkTimeValidity(Integer.parseInt(yearTF.getText().trim()), Integer.parseInt(monthTF.getText().trim()), Integer.parseInt(dayTF.getText().trim()))) {
						 JOptionPane.showMessageDialog(null, "��/��/���� �ùٸ��� ���� �����Դϴ�!", "Error", JOptionPane.WARNING_MESSAGE);
					}
					else if(seati != btnInfo.getRow() || seatj != btnInfo.getCol()
							|| year !=Integer.parseInt(yearTF.getText().trim())
							|| month != Integer.parseInt(monthTF.getText().trim())
							|| day != Integer.parseInt(dayTF.getText().trim()))
					{
						seati=btnInfo.getRow();
						seatj=btnInfo.getCol();
						syear = yearTF.getText().trim();		year = Integer.parseInt(syear);
						smonth = monthTF.getText().trim();		month = Integer.parseInt(smonth);
						sday = dayTF.getText().trim();			day = Integer.parseInt(sday);
						// Label�� ���� ���� ���� ǥ��
						yearL.setText(syear + "��");
						monthL.setText(smonth + "��");
						dayL.setText(sday + "��");
						seatL.setText("<"+seati+", "+seatj+">");						
						// ��ư ��� �ʱ�ȭ(������ Ȱ��ȭ, ��Ҹ� ����)
						for(int k=START_TIME; k<END_TIME; k++) {
							timeBtn.get(k-START_TIME).setEnabled(reserveFlag);
						}
						// �ش� �¼� ������ ���������� ����
						while(rsrvSeat == null) {
							try {
								Thread.sleep(20);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						// ��� ����ð� Ȯ��
						Seat iterator=rsrvSeat;
						int dateInteger = year*10000+month*100+day;
						while(iterator!=null) {
							//System.out.println(iterator.getReservationTime());
							Time stime = iterator.getStartTime();
							// ���� ��¥ ã��
							if(dateInteger == stime.getDateInt()){
								Time etime = iterator.getEndTime();
								// ����� �ð��� Ȯ��
								for(int k=stime.getTimeInt(); k<etime.getTimeInt(); k++) {
									// �����̸� ���� ��Ҹ� Ȱ��ȭ
									timeBtn.get(k-START_TIME).setEnabled(!reserveFlag);
								}
							}
							iterator=iterator.getNextSeat();
						}
						rsrvSeat = null;
					}
				});
				seatPanel.add(btn);
			}
		}
	}
	// Ÿ�����̺�
	public void makeTimeBtn() {
		for(int i=START_TIME; i<END_TIME; i++) {
			// n��-n+1�� ��ư
			String timeNum = i + " - " + (i+1);
			JButton btn = new JButton(timeNum);
			timeBtn.add(btn);
			btn.addActionListener(event->{
				// dialog box Ȯ��
				int result = JOptionPane.showConfirmDialog(null, (reserveFlag ? "����" : "���") + "�Ͻðڽ��ϱ�?", "*^~^*",
                        JOptionPane.OK_CANCEL_OPTION);
				if(result == 0) {
					// atoi ����
					if(btn.getText().charAt(1) == ' ')
						sstartTime = btn.getText().substring(0,1);
					else
						sstartTime = btn.getText().substring(0,2);
					startTime = Integer.parseInt(sstartTime);
					endTime = startTime + 1;
					btn.setEnabled(false);

				}
			});
			btn.setEnabled(false);// ó���� ��� ��Ȱ��ȭ
			timePanel.add(btn);
		}	
	}
	//
	public JFrame getFrame() {
		return rsrvFrame;
	}
}