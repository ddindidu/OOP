package oop.seats;

import java.awt.*;
import javax.swing.*;

public class MainFrame{
	protected int choice;
	
	public void setFrame(JFrame f, String name) {
		f.setTitle(name);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		// ���� ��ǻ�� ȭ�� ũ��
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		
		// frame ũ��� ��ġ ����
		f.setSize(600, 600);
		f.setLocationByPlatform(true);
		f.setLocation(screenWidth/4, screenHeight/4);
	}
	
	public void addButton(JPanel p, String name, int n) {
		JButton btn = new JButton(name);
		btn.setFont(new Font("���� ����", Font.BOLD, 20));
		btn.addActionListener(event->{
			choice = n;
		});
		p.add(btn);
	}
	
	public JFrame getFrame() {
		return null;
	}
}
