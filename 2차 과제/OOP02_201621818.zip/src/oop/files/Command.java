package oop.files;

public class Command {
	public static boolean commandChecker(String command) {
		if(command.compareTo("new")==0		|| command.compareTo("del")==0 		||
			command.compareTo("mkdir")==0 	|| command.compareTo("show")==0 	||
			command.compareTo("chdir")==0 	|| command.compareTo("chmod")==0 	||
			command.compareTo("cwd")==0)
		{
			return true;
		}
		
		return false;
	}
	
	public static boolean accessChecker(String a) {
		if(a.compareTo("+r")==0 || a.compareTo("+w")==0 || a.compareTo("+rw")==0 || a.compareTo("+")==0)
			return true;
		else
			return false;
	}
	
	public static boolean fileNameChecker(String n) {
		char chr;
		chr=n.charAt(0);
		if(!(chr>='A' && chr<='Z' || chr>='a' && chr<='z' || chr>='0' && chr<='9')) {
			return false;
		}
		
		for(int i=1; i<n.length(); i++) {
			chr=n.charAt(i);
			if(!(chr>='A' && chr<='Z' || chr>='a' && chr<='z' || chr>='0' && chr<='9')){
				return false;
			}
		}
		return true;
	}
	
	public static boolean upperDirNameChecker(String n) {
		if(n.compareTo("..")==0)
			return true;
		else
			return false;
	}
	
	public static boolean currDirNameChecker(String n) {
		if(n.compareTo(".")==0)
			return true;
		else
			return false;
	}
	
	// content�� �Էµ����� true
	public static boolean contentChecker(String cont) {
		if(cont.compareTo("")!=0)
			return true;
		else
			return false;
	}
	
	public static boolean lengthChecker(String command, int len) {
		switch(command)
		{
		case "new":
			if(len<2)	return false;
			else		return true;
		case "del":
			if(len>=2)	return true;
			else		return true;
		case "mkdir":
			if(len>=2)	return true;
			else 		return false;
		case "show":
			if(len>=2)	return true;
			else		return false;
		case "chdir":
			if(len>=2)	return true;
			else		return false;
		case "chmod":
			if(len>=2)	return true;
			else		return false;
		case "cwd":
			if(len>0)	return true;
			else 		return false;
		}
		return false;
	}
}
