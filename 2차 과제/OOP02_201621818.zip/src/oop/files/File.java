package oop.files;

public class File extends Property{
	private String content;
	
	public File(String n) {
		super(n);
		isDir = false;
	}
	public File(String n, String perm, String cont) {
		super(n, perm);
		isDir = false;
		content=cont;
	}
	
	@Override
	public void printProperty() {
		System.out.println(getName()+getPermission());
	}
	
	@Override
	public void show() {
		System.out.println(content);
	}
}
