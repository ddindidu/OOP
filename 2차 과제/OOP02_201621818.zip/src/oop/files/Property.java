package oop.files;

public class Property{
	private String name;
	private boolean rPermission = true;
	private boolean wPermission = true;
	protected boolean isDir = false;
	
	public Property(String n) {
		name=n;
	}
	public Property(String n, String perm) {
		name=n;
		changeAcsMode(perm);
	}
	
	public boolean isReadable() { return rPermission; }
	public boolean isWritable() { return wPermission; }
	public boolean isDirectory() { return isDir; }
	public String getName() { return name; }
	public String getPermission() {
		if(rPermission==true && wPermission==true)
			return "+rw";
		else if(rPermission==true && wPermission==false)
			return "+r";
		else if(rPermission==false && wPermission==true)
			return "+w";
		else
			return "+";
	}
	public void changeAcsMode(String a) {
		if(a.compareTo("+rw")==0) {
			rPermission=true;
			wPermission=true;
		}
		else if(a.compareTo("+r")==0) {
			rPermission=true;
			wPermission=false;
		}
		else if(a.compareTo("+w")==0) {
			rPermission=false;
			wPermission=true;
		}
		else if(a.compareTo("+")==0) {
			rPermission=false;
			wPermission=false;
		}
	}

	@Override
	public boolean equals(Object o) {
		Property other = (Property)o;
		String myName = this.name;
		if(myName.contentEquals(other.getName()))
			return true;
		else
			return false;
	}
	
	public void printProperty() {	 }
	public void show() {	}
}
