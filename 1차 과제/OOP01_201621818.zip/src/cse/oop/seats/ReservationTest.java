package cse.oop.seats;

public class ReservationTest {
	public static void main(String[] args) {
		Manager helper = new Manager();
		
		while(true) {
			int userChoice = Manager.printMenu();
			switch(userChoice) {
			case 1:
				helper.reserve();
				break;
			case 2:
				helper.cancel();
				break;
			case 3:
				helper.allReservation();
				break;
			case 4:
				System.out.println("\n+----------------------+");
				System.out.println(" �¼� ���� �ý����� ����˴ϴ�.");
				System.out.println("+----------------------+");
				return;
			}
		}
	}
}
